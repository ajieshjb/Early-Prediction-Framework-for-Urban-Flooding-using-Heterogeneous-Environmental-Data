| Model | F1 1h | F1 3h | F1 6h | RMSE 1h / 3h / 6h (m) |
|---|---|---|---|---|
| Persistence / threshold rule | 0.8972 | 0.7260 | 0.5455 | 0.067 / 0.150 / 0.208 |
| Random Forest (tabular only) | 0.9517 | 0.8492 | 0.6684 | 0.049 / 0.109 / 0.160 |
