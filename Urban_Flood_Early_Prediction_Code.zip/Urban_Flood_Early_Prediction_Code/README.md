# Urban flood early prediction (PBL III)

One script, `urban_flood.py`, that builds a synthetic city, trains the models and writes the results for your slides.

## Run
    pip install -r requirements.txt
    python urban_flood.py              # all four models, ~5-15 min on a laptop CPU
    python urban_flood.py --no-dl      # persistence + Random Forest only (~40 s, no PyTorch)
    python urban_flood.py --epochs 40 --seed 7

## What it does
- Synthetic city: 24 grid cells (6x4), 3000 hours. Static maps: elevation, slope, imperviousness, drainage, distance to river. Dynamic: rainfall (moving storms), river level, soil moisture, with sensor noise.
- Flood depth comes from a simple runoff + river-overflow model. A cell is flooded when depth > 0.15 m.
- Models see the last 12 hours and predict flood occurrence and depth at 1 h, 3 h and 6 h.
- Time-based split: train 70% / val 15% / test 15% (test = 10,656 samples). F1 thresholds are tuned on validation only.
- Models: Persistence rule, Random Forest (tabular), LSTM only, CNN + LSTM with attention fusion.
- Class imbalance: weighted BCE. Depth: Smooth-L1.

## Outputs (./outputs)
results.json, results.md (slide table), lead_time_f1.png, training_curve.png (with PyTorch), dataset_summary.json

## Be honest in the viva
The data is synthetic, so results show the framework works, not that it works on a real city. The test period has more floods than train/val (a harder, shifted period). Live alerts and the risk map are not implemented.
