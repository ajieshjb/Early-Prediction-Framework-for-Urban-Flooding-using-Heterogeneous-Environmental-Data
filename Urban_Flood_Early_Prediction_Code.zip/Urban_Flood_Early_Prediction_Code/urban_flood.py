#!/usr/bin/env python3
"""
Urban flood early prediction: CNN + LSTM attention fusion vs baselines.

Everything runs on a SYNTHETIC city (24 grid cells, 3000 hours) generated
below, so results are for demonstration, not for a real study area.

Usage
-----
  python urban_flood.py                 # all models (needs PyTorch)
  python urban_flood.py --no-dl         # persistence + Random Forest only
  python urban_flood.py --epochs 40 --seed 7

Outputs (in ./outputs): results.json, results.md, lead_time_f1.png,
training_curve.png (only with PyTorch), dataset_summary.json
"""
import argparse, json, os, time
import numpy as np
from scipy.ndimage import gaussian_filter
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.metrics import f1_score, precision_score, recall_score, accuracy_score

HORIZONS = [1, 3, 6]          # lead times in hours
WINDOW = 12                   # past hours given to the models
GH, GW = 4, 6                 # city grid -> 24 cells
N_CELLS = GH * GW
FLOOD_DEPTH = 0.15            # metres: depth above which a cell counts as flooded
T_TOTAL = 3000                # hours simulated


# ----------------------------------------------------------------------------
# 1. Synthetic data: terrain, land use, rainfall, river, soil, flood depth
# ----------------------------------------------------------------------------
def make_city(seed=42, hours=T_TOTAL):
    rng = np.random.default_rng(seed)
    yy, xx = np.mgrid[0:GH, 0:GW].astype(float)

    def smooth(scale):
        return gaussian_filter(rng.normal(size=(GH, GW)), scale, mode="nearest")

    # static maps; the river runs along row 0 so low rows are riskier
    elev = 6.0 + 1.4 * yy + 2.5 * smooth(1.0)
    gy, gx = np.gradient(elev)
    slope = np.hypot(gy, gx)
    imperv = np.clip(0.55 + 1.2 * smooth(1.0), 0.10, 0.95)     # land use
    drain = np.clip(0.55 + 1.0 * smooth(1.0), 0.15, 1.00)      # drainage capacity
    dist_river = yy
    static = np.stack([elev, slope, imperv, drain, dist_river])  # (5, GH, GW)

    # rainfall: moving storm cells over a light background drizzle
    rain = np.zeros((hours, GH, GW))
    t = 0
    while t < hours:
        t += int(rng.exponential(70))
        dur = int(rng.integers(3, 11))
        peak = rng.gamma(3.0, 6.0)                 # mm/h
        cy, cx = rng.uniform(0, GH), rng.uniform(0, GW)
        vy, vx = rng.normal(0, 0.15, 2)
        sig = rng.uniform(1.5, 3.5)
        for k in range(dur):
            if t + k >= hours:
                break
            shape = np.sin(np.pi * (k + 0.5) / dur)
            d2 = (yy - (cy + vy * k)) ** 2 + (xx - (cx + vx * k)) ** 2
            rain[t + k] += peak * shape * np.exp(-d2 / (2 * sig ** 2))
    rain += rng.gamma(0.3, 0.15, size=rain.shape) * (rng.random(rain.shape) < 0.15)

    # hydrology: surface water store, river level (lagged catchment rain), soil
    water = np.zeros_like(rain)
    soil = np.zeros_like(rain)
    river = np.zeros(hours)
    mean_rain = rain.mean(axis=(1, 2))
    for k in range(1, hours):
        water[k] = 0.62 * water[k - 1] + rain[k] * imperv
        soil[k] = np.clip(0.93 * soil[k - 1] + 0.05 * rain[k], 0, 1.5)
        river[k] = 0.90 * river[k - 1] + 0.30 * mean_rain[max(k - 3, 0)]

    low = (elev.max() - elev) / (elev.max() - elev.min())      # 0 high, 1 low
    local = 0.020 * np.clip(water - 18.0 * drain, 0, None) * (0.6 + 1.2 * low)
    local = local * (1 + 0.6 * soil)
    over = 0.060 * np.clip(river - 6.0, 0, None)[:, None, None]
    over = over * np.exp(-dist_river / 1.5) * (0.4 + low)
    depth = np.clip(local + over, 0, None)
    depth = np.clip(depth + rng.normal(0, 0.01, depth.shape), 0, None)

    # what the models are allowed to see (noisy sensors)
    obs = np.stack([
        rain + rng.normal(0, 0.15, rain.shape),
        np.repeat(mean_rain[:, None, None], GH, 1).repeat(GW, 2),
        np.repeat((river + rng.normal(0, 0.2, hours))[:, None, None], GH, 1).repeat(GW, 2),
        soil + rng.normal(0, 0.02, soil.shape),
    ], axis=-1)                                                # (T, GH, GW, 4)
    return dict(static=static, obs=obs.reshape(hours, N_CELLS, 4),
                depth=depth.reshape(hours, N_CELLS))


def make_samples(city):
    """Time-based split: train 70% / val 15% / test 15% of the 3000 hours."""
    obs, depth, T = city["obs"], city["depth"], city["depth"].shape[0]
    hmax = max(HORIZONS)
    t_val, t_test = int(0.70 * T), int(0.85 * T)
    ranges = {"train": (WINDOW - 1, t_val - hmax - 1),
              "val": (t_val, t_test - hmax - 1),
              "test": (t_test, T - hmax - 1)}
    out = {}
    for name, (a, b) in ranges.items():
        ts = np.arange(a, b + 1)
        seq = np.stack([obs[t - WINDOW + 1: t + 1] for t in ts])          # (nt, W, C, 4)
        seq = seq.transpose(0, 2, 1, 3).reshape(-1, WINDOW, 4)            # sample = (t, cell)
        cell = np.tile(np.arange(N_CELLS), len(ts))
        y_depth = np.stack([depth[ts + h] for h in HORIZONS], axis=-1).reshape(-1, len(HORIZONS))
        now = depth[ts].reshape(-1)
        out[name] = dict(seq=seq.astype(np.float32), cell=cell,
                         depth=y_depth.astype(np.float32),
                         flood=(y_depth > FLOOD_DEPTH).astype(np.float32),
                         now=now.astype(np.float32))
    return out


# ----------------------------------------------------------------------------
# 2. Metrics + threshold calibration
# ----------------------------------------------------------------------------
def best_threshold(y, p):
    grid = np.linspace(0.05, 0.95, 19)
    scores = [f1_score(y, p >= g, zero_division=0) for g in grid]
    return float(grid[int(np.argmax(scores))])


def evaluate(name, val, test, p_val, p_test, d_test, fixed_thr=None):
    res = {"model": name, "f1": [], "precision": [], "recall": [], "accuracy": [],
           "rmse": [], "threshold": []}
    for i in range(len(HORIZONS)):
        thr = fixed_thr if fixed_thr is not None else best_threshold(val["flood"][:, i], p_val[:, i])
        pred = p_test[:, i] >= thr
        y = test["flood"][:, i]
        res["f1"].append(float(f1_score(y, pred, zero_division=0)))
        res["precision"].append(float(precision_score(y, pred, zero_division=0)))
        res["recall"].append(float(recall_score(y, pred, zero_division=0)))
        res["accuracy"].append(float(accuracy_score(y, pred)))
        res["rmse"].append(float(np.sqrt(np.mean((d_test[:, i] - test["depth"][:, i]) ** 2))))
        res["threshold"].append(thr)
    return res


# ----------------------------------------------------------------------------
# 3. Baselines: persistence rule and Random Forest on tabular features
# ----------------------------------------------------------------------------
def tabular(split, static):
    s, cell = split["seq"], split["cell"]
    st = static.reshape(5, -1).T[cell]
    feats = [s[:, -1, :], s[:, -3:, 0].sum(1, keepdims=True), s[:, -6:, 0].sum(1, keepdims=True),
             s[:, :, 0].sum(1, keepdims=True), s[:, :, 0].max(1, keepdims=True),
             s[:, :, 2].max(1, keepdims=True), st, (cell // GW)[:, None], (cell % GW)[:, None]]
    return np.hstack(feats)


def run_persistence(val, test):
    flooded = (test["now"] > FLOOD_DEPTH).astype(float)
    p = np.repeat(flooded[:, None], len(HORIZONS), 1)
    d = np.repeat(test["now"][:, None], len(HORIZONS), 1)
    return evaluate("Persistence / threshold rule", val, test, p, p, d, fixed_thr=0.5)


def run_rf(sets, static, seed):
    Xtr, Xva, Xte = (tabular(sets[k], static) for k in ("train", "val", "test"))
    clf = RandomForestClassifier(n_estimators=120, max_depth=14, min_samples_leaf=3,
                                 n_jobs=-1, random_state=seed)
    reg = RandomForestRegressor(n_estimators=120, max_depth=14, min_samples_leaf=3,
                                max_features=0.5, n_jobs=-1, random_state=seed)
    clf.fit(Xtr, sets["train"]["flood"].astype(int))
    reg.fit(Xtr, sets["train"]["depth"])
    prob = lambda X: np.stack([c[:, 1] for c in clf.predict_proba(X)], axis=1)
    return evaluate("Random Forest (tabular only)", sets["val"], sets["test"],
                    prob(Xva), prob(Xte), reg.predict(Xte))


# ----------------------------------------------------------------------------
# 4. Deep models (PyTorch): LSTM-only and CNN + LSTM attention fusion
# ----------------------------------------------------------------------------
def run_deep(sets, static, seed, epochs, use_spatial, label, curve=None):
    import torch
    import torch.nn as nn
    torch.manual_seed(seed)
    np.random.seed(seed)
    dev = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    mu = sets["train"]["seq"].reshape(-1, 4).mean(0)
    sd = sets["train"]["seq"].reshape(-1, 4).std(0) + 1e-6
    smu = static.reshape(5, -1).mean(1)[:, None, None]
    ssd = static.reshape(5, -1).std(1)[:, None, None] + 1e-6
    static_t = torch.tensor((static - smu) / ssd, dtype=torch.float32)[None].to(dev)  # (1,5,GH,GW)

    def tens(split):
        return (torch.tensor((split["seq"] - mu) / sd, dtype=torch.float32),
                torch.tensor(split["cell"], dtype=torch.long),
                torch.tensor(split["flood"]), torch.tensor(split["depth"]))

    tr, va, te = tens(sets["train"]), tens(sets["val"]), tens(sets["test"])
    n_h, hid = len(HORIZONS), 64

    class FloodNet(nn.Module):
        def __init__(self):
            super().__init__()
            self.lstm = nn.LSTM(4, hid, batch_first=True)
            if use_spatial:
                self.cnn = nn.Sequential(
                    nn.Conv2d(5, 32, 3, padding=1), nn.ReLU(),
                    nn.Conv2d(32, hid, 3, padding=1), nn.ReLU())
                self.attn = nn.MultiheadAttention(hid, 4, batch_first=True)
                self.norm = nn.LayerNorm(hid)
            self.body = nn.Sequential(nn.Linear(hid, hid), nn.ReLU(), nn.Dropout(0.2))
            self.occ = nn.Linear(hid, n_h)
            self.dep = nn.Linear(hid, n_h)

        def forward(self, seq, cell):
            _, (h, _) = self.lstm(seq)
            z = h[-1]                                            # temporal embedding (B,hid)
            if use_spatial:
                fmap = self.cnn(static_t)[0].reshape(hid, -1).T  # (cells, hid)
                s = fmap[cell]                                   # spatial embedding (B,hid)
                tokens = torch.stack([z, s], dim=1)              # (B,2,hid)
                a, _ = self.attn(z.unsqueeze(1), tokens, tokens) # attention fusion
                z = self.norm(z + s + a.squeeze(1))
            z = self.body(z)
            return self.occ(z), torch.relu(self.dep(z))

    model = FloodNet().to(dev)
    pos = tr[2].mean(0).clamp(min=1e-4)
    bce = nn.BCEWithLogitsLoss(pos_weight=((1 - pos) / pos).clamp(max=30).to(dev))  # class imbalance
    huber = nn.SmoothL1Loss()
    opt = torch.optim.Adam(model.parameters(), lr=2e-3)

    def loss_fn(logit, dep, yf, yd):
        return bce(logit, yf) + 5.0 * huber(dep, yd)

    def predict(data, bs=4096):
        model.eval(); P, D = [], []
        with torch.no_grad():
            for i in range(0, len(data[0]), bs):
                lo, de = model(data[0][i:i + bs].to(dev), data[1][i:i + bs].to(dev))
                P.append(torch.sigmoid(lo).cpu()); D.append(de.cpu())
        return torch.cat(P).numpy(), torch.cat(D).numpy()

    def val_loss():
        model.eval(); tot, n = 0.0, 0
        with torch.no_grad():
            for i in range(0, len(va[0]), 4096):
                sl = slice(i, i + 4096)
                lo, de = model(va[0][sl].to(dev), va[1][sl].to(dev))
                tot += loss_fn(lo, de, va[2][sl].to(dev), va[3][sl].to(dev)).item() * len(va[0][sl])
                n += len(va[0][sl])
        return tot / n

    best, best_state, bad, hist = 1e9, None, 0, []
    for ep in range(epochs):
        model.train()
        perm = torch.randperm(len(tr[0]))
        run = 0.0
        for i in range(0, len(perm), 512):
            idx = perm[i:i + 512]
            lo, de = model(tr[0][idx].to(dev), tr[1][idx].to(dev))
            loss = loss_fn(lo, de, tr[2][idx].to(dev), tr[3][idx].to(dev))
            opt.zero_grad(); loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            opt.step(); run += loss.item() * len(idx)
        vl = val_loss()
        hist.append((run / len(perm), vl))
        print(f"  [{label}] epoch {ep + 1:02d}  train {hist[-1][0]:.4f}  val {vl:.4f}", flush=True)
        if vl < best - 1e-4:
            best, bad = vl, 0
            best_state = {k: v.clone() for k, v in model.state_dict().items()}
        else:
            bad += 1
            if bad >= 6:
                print("  early stopping"); break
    model.load_state_dict(best_state)
    if curve is not None:
        curve[label] = hist
    p_va, _ = predict(va)
    p_te, d_te = predict(te)
    return evaluate(label, sets["val"], sets["test"], p_va, p_te, d_te)


# ----------------------------------------------------------------------------
# 5. Reporting
# ----------------------------------------------------------------------------
def write_reports(results, curve, outdir, meta):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    os.makedirs(outdir, exist_ok=True)
    json.dump({"meta": meta, "results": results}, open(f"{outdir}/results.json", "w"), indent=2)

    lines = ["| Model | F1 1h | F1 3h | F1 6h | RMSE 1h / 3h / 6h (m) |", "|---|---|---|---|---|"]
    for r in results:
        lines.append(f"| {r['model']} | " + " | ".join(f"{v:.4f}" for v in r["f1"]) + " | "
                     + " / ".join(f"{v:.3f}" for v in r["rmse"]) + " |")
    open(f"{outdir}/results.md", "w").write("\n".join(lines) + "\n")
    print("\n" + "\n".join(lines))

    plt.figure(figsize=(6.4, 4))
    for r in results:
        plt.plot(HORIZONS, r["f1"], marker="o", label=r["model"])
    plt.xticks(HORIZONS); plt.xlabel("Lead time (h)"); plt.ylabel("F1 (flood occurrence)")
    plt.title("F1 by lead time (test set, synthetic data)"); plt.grid(alpha=.3); plt.legend(fontsize=8)
    plt.tight_layout(); plt.savefig(f"{outdir}/lead_time_f1.png", dpi=160); plt.close()

    if curve:
        plt.figure(figsize=(6.4, 4))
        for name, h in curve.items():
            h = np.array(h)
            plt.plot(h[:, 0], label=f"{name} train"); plt.plot(h[:, 1], "--", label=f"{name} val")
        plt.xlabel("Epoch"); plt.ylabel("Loss"); plt.title("Training curves"); plt.legend(fontsize=7)
        plt.grid(alpha=.3); plt.tight_layout(); plt.savefig(f"{outdir}/training_curve.png", dpi=160)
        plt.close()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--no-dl", action="store_true", help="skip PyTorch models")
    ap.add_argument("--epochs", type=int, default=30)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--out", default="outputs")
    a = ap.parse_args()

    t0 = time.time()
    city = make_city(a.seed)
    sets = make_samples(city)
    meta = {"seed": a.seed, "cells": N_CELLS, "hours": T_TOTAL, "window_h": WINDOW,
            "flood_threshold_m": FLOOD_DEPTH, "data": "synthetic",
            "samples": {k: int(len(v["cell"])) for k, v in sets.items()},
            "flood_rate_by_lead": {k: [float(x) for x in v["flood"].mean(0)] for k, v in sets.items()}}
    os.makedirs(a.out, exist_ok=True)
    json.dump(meta, open(f"{a.out}/dataset_summary.json", "w"), indent=2)
    print("Dataset:", json.dumps(meta, indent=2))

    results, curve = [run_persistence(sets["val"], sets["test"])], {}
    print("Random Forest ..."); results.append(run_rf(sets, city["static"], a.seed))
    if not a.no_dl:
        print("LSTM only ...")
        results.append(run_deep(sets, city["static"], a.seed, a.epochs, False, "LSTM only (temporal)", curve))
        print("CNN + LSTM fusion ...")
        results.append(run_deep(sets, city["static"], a.seed, a.epochs, True, "Proposed CNN + LSTM fusion", curve))
    write_reports(results, curve, a.out, meta)
    print(f"\nDone in {time.time() - t0:.0f}s -> {a.out}/")


if __name__ == "__main__":
    main()
